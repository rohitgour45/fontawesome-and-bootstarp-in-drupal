<?php echo "This is login page";?>

<?php  global $base_url;?>


<div id="page">
	<header id="masthead" class="site-header container" role="banner">
		<div class="row">
		  <div id="logo" class="site-branding col-sm-6">
			<?php if ($logo): ?><div id="site-logo"><a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>">
			  <img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" />
			</a></div><?php endif; ?>
			<h1 id="site-title">
			  <a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>"><?php print $site_name; ?></a>
			</h1>
		  </div>
		  <div class="col-sm-6 mainmenu">
			<div class="mobilenavi"></div>
			<nav id="navigation" role="navigation">
			  <div id="main-menu">
				<?php 
				  if (module_exists('i18n_menu')) {
					$main_menu_tree = i18n_menu_translated_tree(variable_get('menu_main_links_source', 'main-menu'));
				  } else {
					$main_menu_tree = menu_tree(variable_get('menu_main_links_source', 'main-menu'));
				  }
				  print drupal_render($main_menu_tree);
				?>
			  </div>
			</nav>
		  </div>
		</div>
  </header>
  
  <?php if($page['header']) : ?>
    <div id="header-block">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <?php print render($page['header']); ?>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>

    <div id="main-content">
    <div class="container"> 
      <div class="row">
        <div class="main-login-parent">
		   <div class="login-text-and-links">
			 <a class="sign-in" href="<?php print $base_url;?>/user/login"><?php print t("Sign in"); ?></a>
			 <a class="sign-up" href="<?php print $base_url;?>/user/register"><?php print t("Sign up"); ?></a>
		   </div>
	       <div class="userlogin-title"><?php print t("WELCOME"); ?></div>
	
			<div class="login-action login-main-form">
				<?php print render($page['content']); ?>
				<div class="forgot-pass">
					<a href="<?php print $base_url;?>/user/password"><?php print t("Forgot Password?"); ?></a>
					
					<section id="content-msg" role="main" class="clearfix">
					<?php print $messages; ?>
					</section>
			    </div>
			</div>
	
            
			<div class="sign-in-icon">
				    <?php print t("sign in with");?>
				    <div class="footer-social-icon">
						<ul>
							<li><a href="#"><img alt="facebook" src=""></a></li>   
							<li><a href="#"><img alt="twitter" src=""></a> </li>          
							<li><a href="#"><img alt="wechat" src=""></a></li>         
						</ul>
					</div>
			</div>	
       </div>
        
        

      </div>
    </div>
  </div>

  <?php if($page['footer']) : ?>
    <div id="footer-block">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <?php print render($page['footer']); ?>
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <?php if ($page['footer_first'] || $page['footer_second'] || $page['footer_third'] || $page['footer_fourth']): ?>
    <?php $footer_col = ( 12 / ( (bool) $page['footer_first'] + (bool) $page['footer_second'] + (bool) $page['footer_third'] + (bool) $page['footer_fourth'] ) ); ?>
    <div id="bottom">
      <div class="container">
        <div class="row">
          <?php if($page['footer_first']): ?><div class="footer-block col-sm-<?php print $footer_col; ?>">
            <?php print render ($page['footer_first']); ?>
          </div><?php endif; ?>
          <?php if($page['footer_second']): ?><div class="footer-block col-sm-<?php print $footer_col; ?>">
            <?php print render ($page['footer_second']); ?>
          </div><?php endif; ?>
          <?php if($page['footer_third']): ?><div class="footer-block col-sm-<?php print $footer_col; ?>">
            <?php print render ($page['footer_third']); ?>
          </div><?php endif; ?>
          <?php if($page['footer_fourth']): ?><div class="footer-block col-sm-<?php print $footer_col; ?>">
            <?php print render ($page['footer_fourth']); ?>
          </div><?php endif; ?>
        </div>
      </div>
    </div>
  <?php endif; ?>

  <footer id="colophon" class="site-footer" role="contentinfo">
    <div class="container">
      <div class="row">
        <div class="fcred col-sm-12">
          <?php print t('Copyright'); ?> &copy; <?php echo date("Y"); ?>, <a href="<?php print $front_page; ?>"><?php print $site_name; ?></a>. <?php print t('Theme by'); ?>  <a href="http://www.devsaran.com" target="_blank">Devsaran</a>.
        </div>
      </div>
    </div>
  </div>
</div>
