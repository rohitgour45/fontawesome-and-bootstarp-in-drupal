<?php echo "This is Developer Registration page"; ?>


<?php global $base_url;?>
	<div id="page">
		<header id="masthead" class="site-header " role="banner">
			<div class="container">
				<div class="row">
					<div id="logo" class="site-branding col-sm-3">
						<?php if ($logo): ?>
						<img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" />
						<?php endif; ?>
					</div>
				<div class="col-sm-6 mainmenu">
					<nav id="navigation" role="navigation">
						<div  class="header-main-menu">
		       <?php print render($page['main_menu']); ?>
             </div>
					</nav>
				</div>
				<div  class="site-branding col-sm-3 right-icon">
					<?php print render($page['header_third']); ?>
				</div>
				</div>
				</div>
  </header>
</div>

<div class="main-content">
<div class="container">
<div class="main-cntn main-login business-form">
	 <?php if($page['sidebar_first']) { $primary_col = 8; } else { $primary_col = 12; } ?>
	<div class="signup-txt login-text">
		<a class="sign-up" href="<?php print $base_url;?>/user/register"><?php print t("Sign up"); ?></a>
	</div>
	<div class="userlogin-title"><?php print t("Developer account"); ?></div>
	<div class="login-action"><?php //print drupal_render_children($form) ?>
		 <?php print render($page['content']); ?>
	<div class="forgot-pass">
		<section id="content" role="main" class="clearfix">
       <?php print $messages; ?>
    </section>
	</div>
	
	</div>
	
            
		
</div>
</div>
</div>

<footer id="colophon" class="site-footer" role="contentinfo">
   <div class="footer-main">
     <div class="container">
		  <div class="row">
				<div class="footer-logo col-sm-2">
					<div  class="footer_logo footer_one">
		               <?php print render($page['footer_one']); ?>
                    </div>
					       
				</div>
			
				<div class="site-footer-menu fcred col-sm-7">
					<div  class="footer_menus footer_two">
					<?php print render($page['footer_menu']); ?>
					</div>
				</div>
			
				<div class="site-social-login fcred col-sm-3">
					
					<div  class="footer_social_icon footer_three">
		               <?php print render($page['footer_three']); ?>
                    </div>
                    
				</div>
				
	       </div>	
	 </div>
   </div>
	   <div class="site-copyright fcred">
			<div class="container">
			  <div class="row col-sm-12">
			        <div  class="footer_copyright">
		               <?php print render($page['footer_copyright']); ?>
                    </div>	  
			
	          </div>
            </div>
       </div>
</footer>
