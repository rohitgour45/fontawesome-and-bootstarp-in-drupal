jQuery(window).load(function() {

  jQuery('#slidebox').flexslider({
    animation: "fade",
    directionNav:true,
    controlNav:false
  });

});